To view these tutorials, expand each zip into its own directory.  

All images and associated files for a tutorial zip are local to the directory that you unzipped the files to.

You can also read these tutorials online at: http://www.macromedia.com/devnet/flex/articles/first_flexapp.html

Enjoy!