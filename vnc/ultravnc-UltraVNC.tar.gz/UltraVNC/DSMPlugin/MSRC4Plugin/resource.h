//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MSRC4Plugin.rc
//
#define IDD_CONFIG_DIALOG               101
#define MSRC4PLUGINDOC                  102
#define MSRC4PLUGIN                     102
#define IDD_DIALOG1                     106
#define MSRC4PLUGIN_NOREG               107
#define OVERVIEW                        108
#define RELEASENOTES                    109
#define INDEX                           110
#define IDC_KEYGEN                      1002
#define ID_MSG                          1003
#define ID_MSG2                         1004
#define IDC_CLIENT                      1005
#define IDC_SERVER                      1006
#define IDC_SERVER_SERVICE              1007
#define IDC_KEYLOCATION                 1008
#define IDC_SERVER_USER                 1009
#define IDC_MSG                         1010
#define IDC_RADIO1                      1010
#define IDC_RADIO2                      1011
#define IDC_BITNESS                     1012
#define IDC_RADIO3                      1013
#define IDC_DELETECONTAINER             1014
#define IDC_STATUS                      1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
