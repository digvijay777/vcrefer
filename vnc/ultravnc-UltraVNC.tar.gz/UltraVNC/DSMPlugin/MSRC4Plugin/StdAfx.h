//#if !defined(AFX_STDAFX_H__213115EB_FB9E_4844_A26F_B6FF22C547BB__INCLUDED_)
//#define AFX_STDAFX_H__213115EB_FB9E_4844_A26F_B6FF22C547BB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// Insert your headers here

