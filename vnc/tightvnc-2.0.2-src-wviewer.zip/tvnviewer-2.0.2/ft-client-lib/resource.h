#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDC_RENAME_REMOTE_BUTTON                1000
#define IDC_LABEL                               1002
#define IDC_FILENAME_EDIT                       1004
#define IDC_LOG_COMBO                           1011
#define IDC_TOTAL_PROGRESS                      1012
#define IDC_LOCAL_FILE_LIST                     1022
#define IDC_REMOTE_FILE_LIST                    1023
#define IDC_FILENAME_LABEL                      1029
#define IDC_SIZE1_LABEL                         1030
#define IDC_SIZE2_LABEL                         1031
#define IDC_DATE1_LABEL                         1032
#define IDC_DATE2_LABEL                         1033
#define IDC_OVERWRITE_BUTTON                    1034
#define IDC_OVERWRITE_ALL_BUTTON                1035
#define IDC_SKIP_BUTTON                         1036
#define IDC_SKIP_ALL_BUTTON                     1037
#define IDC_APPEND_BUTTON                       1038
#define IDC_CANCEL_BUTTON                       1039
#define IDC_REMOTE_CURRENT_FOLDER_EDIT          1040
#define IDC_LOCAL_CURRENT_FOLDER_EDIT           1046
#define IDC_MKDIR_REMOTE_BUTTON                 1047
#define IDC_REMOVE_REMOTE_BUTTON                1048
#define IDC_REFRESH_REMOTE_BUTTON               1049
#define IDC_RENAME_LOCAL_BUTTON                 1051
#define IDC_MKDIR_LOCAL_BUTTON                  1053
#define IDC_REMOVE_LOCAL_BUTTON                 1055
#define IDC_REFRESH_LOCAL_BUTTON                1057
#define IDC_UPLOAD_BUTTON                       1059
#define IDC_DOWNLOAD_BUTTON                     1061
